function toggleMenu() {
    const menu = document.getElementById("sideMenu");
    menu.classList.toggle("open");
}